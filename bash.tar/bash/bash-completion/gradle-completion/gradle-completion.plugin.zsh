compdef _gradle gradle
compdef _gradle gradlew
compdef _gradle gw
